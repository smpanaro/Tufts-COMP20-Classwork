var express = require('express'),
    exphbs  = require('express3-handlebars')
    logfmt = require("logfmt"),
    moment = require('moment');

var app = express(),
    mongo = require('mongodb');

var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost:27017/local';
var scoreCollection = "scoreCollection";

app.use(logfmt.requestLogger());
app.use(express.json()); // parse posted json data
app.use(express.static(__dirname + '/static'));

app.engine('handlebars', exphbs({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

app.all('*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type,X-Requested-With");
  res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  next();
});

app.get('/', function(req, res) {
  mongo.Db.connect(mongoUri, function (err, db) {
    db.collection(scoreCollection, function(er, collection) {
      collection.find({}).toArray(function(err, results) {
        results = results.sort(function(a,b) {return b.score-a.score;});
        results = results.map(function(x) {
          x.relative_timestamp = moment(x.created_at).fromNow();
          return x;
        });
        res.render('home', {games : results});
      });
    });
  });
});

app.get('/scores.json', function(req, res){
  console.log("searching for " + req.query.username);

  var username = req.query.username;

  mongo.Db.connect(mongoUri, function (err, db) {
    db.collection(scoreCollection, function(er, collection) {
      collection.find({"username":username}).toArray(function(err, results) {
        results = results.sort(function(a,b) {return b.score-a.score;});
        res.send(results);
      });
    });
  });
});

app.get('/games.json', function(req, res) {
  mongo.Db.connect(mongoUri, function (err, db) {
    db.collection(scoreCollection, function(er, collection) {
      collection.find({}).toArray(function(err, results) {
        res.send(results);
      });
    });
  });
});

// Expects an object with keys: username, score, grid
// Ignores anything that does not have those keys.
app.post('/submit.json', function(req, res) {
  console.log("received new score");

  var username = req.body.username;
  var grid = req.body.grid;
  var score = req.body.score;
  var created_at = new Date();

  if (username !== undefined || grid !== undefined || score !== undefined) {

    mongo.Db.connect(mongoUri, function (err, db) {
      db.collection(scoreCollection, function(er, collection) {
        collection.insert(
            {"username":username, "grid":grid, "score":score, "created_at": created_at},
            {safe: true},
            function(er,rs) {}
            );
      });
    });

  }

  res.send();
});

var port = Number(process.env.PORT || 5000);
var server = app.listen(port, function() {
  console.log('Listening on port %d', port);
});